### Template Information

**Name:** WE1S Workspace Project Template
**Version:** 0.1.9
**Contributors:** Jeremy Douglass, Scott Kleinman, Lindsay Thomas
**Date:** 2021-27-02